package PageObjects;

import java.io.IOException;


public class AppiumLocators {


    public String textFields() throws IOException {
        return ("TextFields");
    }

    public String normal() throws IOException {
        return ("Normal");
    }

    public String controls() throws IOException {
        return ("Controls");
    }

    public String pickers() throws IOException {
        return ("Pickers");
    }

    public String standardSwitch() throws IOException {
        return ("Standard");
    }

    public String images() throws IOException {
        return ("Images");
    }

    public String durationSlider() throws IOException {
        return ("Duration");
    }

    public String alerts() throws IOException {
        return ("Alerts");
    }

    public String web() throws IOException {
        return ("Web");
    }

    public String showSimple() throws IOException {
        return ("Show Simple");
    }

    public String acceptAlert() throws IOException {
        return ("OK");
    }

    public String okCancel() throws IOException {
        return ("Show OK-Cancel");
    }

    public String cancel() throws IOException {
        return ("Cancel");
    }


    public String backButton() throws IOException {
        return ("Back");
    }
}

