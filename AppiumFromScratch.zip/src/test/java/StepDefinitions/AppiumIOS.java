package StepDefinitions;

import Appium.Driver;
import PageObjects.AppiumLocators;
import cucumber.api.PendingException;
import cucumber.api.java.Before;
import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import io.appium.java_client.ios.IOSDriver;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.openqa.selenium.remote.RemoteWebElement;

import java.io.File;
import java.net.URL;
import java.util.HashMap;

import static org.junit.Assert.assertEquals;

public class AppiumIOS extends Driver {

    DesiredCapabilities caps = new DesiredCapabilities();
    AppiumLocators appium = new AppiumLocators();


    @Given("^I am using Appium for device \"([^\"]*)\" and IOS version \"([^\"]*)\"$")
    public void iAmUsingAppiumForDeviceAndIOSVersion(String Device, String IOS) throws Throwable {
        caps.setCapability("deviceName", Device);
        caps.setCapability("platformVersion", IOS);
        caps.setCapability("automationName", "XCUITest");
//        caps.setCapability("autoAcceptAlerts", "true");
    }

    @And("^I am using the app directory of \"([^\"]*)\" and app \"([^\"]*)\"$")
    public void iAmUsingTheAppDirectoryOfAndApp(String dir, String app) throws Throwable {
        File appDir = new File(dir);
        File appPath = new File(appDir, app);
        caps.setCapability("app", appPath);
    }

    @Then("^I launch the App on the Device$")
    public void iLaunchTheAppOnTheDevice() throws Throwable {
        driver = new IOSDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), caps);
    }

    @And("^I run sample example tests$")
    public void iRunSampleExampleTests() throws Throwable {

        // Usually I would seperate each of these tests into individual Gherkin statements

        //Open Images from the Menu, Adjust Slider to 90%
        //Get Device Time, Take Screenshot (also screenshot when Element is Not found is implemented)
        //Set GeoLocation, Output Session caps, Swipe Down example

        findElementWithTimeout(By.name(appium.images()), 10).click();
        findElementWithTimeout((By.id(appium.durationSlider())), 10).sendKeys("0.9");
        getDeviceTime();
        iTakeAScreenshot();
        setLocation(45, 45, 100);
        ouputSessionCapabilities();
        swipeDown();

        driver.findElement(By.id(appium.backButton())).click();

        //Alerts examples
        WebElement alerts = driver.findElementByAccessibilityId(appium.alerts());
        alerts.click();

        driver.findElementByName(appium.showSimple()).click();

        WebElement element = driver.findElementByName(appium.acceptAlert());
        assertEquals("OK", element.getText());
        driver.findElementByName(appium.acceptAlert()).click();
        driver.findElementByName(appium.okCancel()).click();
        driver.findElementByName(appium.acceptAlert()).click();
        driver.findElementByName(appium.okCancel()).click();
        driver.findElementByName(appium.cancel()).click();

        driver.findElement(By.id(appium.backButton())).click();

        //Picker element example using XCUI Test and JScript
        driver.findElement(By.id(appium.backButton())).click();
        driver.findElement(By.id(appium.pickers())).click();
        RemoteWebElement elements = (RemoteWebElement) driver.findElement(By.xpath("//XCUIElementTypeApplication[@name=\"UICatalog\"]/XCUIElementTypeWindow[1]/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeOther/XCUIElementTypeScrollView/XCUIElementTypePicker/XCUIElementTypePickerWheel[1]"));
        JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, Object> params = new HashMap<String, Object>();
        params.put("order", "next");
        params.put("offset", 0.15);
        params.put("element", ((RemoteWebElement) elements).getId());
        js.executeScript("mobile: selectPickerWheelValue", params);

    }

    @Then("^I close down the simulator$")
    public void iCloseDownTheSimulatorFor(String device) throws Throwable {
        driver.quit();
    }

    // Mobile browser caps and example
    @Given("^I am using Safari mobile browser to visit \"([^\"]*)\"$")
    public void iAmUsingSafariMobileBrowserToVisit(String url) throws Throwable {
        caps.setCapability("deviceName", "iPhone 6");
        caps.setCapability("platformName", "iOS");
        caps.setCapability("platformVersion", "11.2");
        caps.setCapability("browserName", "safari");
        driver = new IOSDriver<>(new URL("http://127.0.0.1:4723/wd/hub"), caps);
        driver.get(url);
    }
}
