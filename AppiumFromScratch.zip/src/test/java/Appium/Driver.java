package Appium;

import cucumber.api.java.gl.E;
import io.appium.java_client.AppiumDriver;
import io.appium.java_client.MobileElement;
import io.appium.java_client.ios.IOSElement;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.By;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.html5.Location;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

import java.io.File;
import java.io.IOException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.TimeZone;

public class Driver {

    public AppiumDriver<IOSElement> driver;

    public MobileElement findElementWithTimeout(By by, int timeOutInSeconds) throws IOException {

        // Output screenshot if Element is not found
        try {
            return (MobileElement) (new WebDriverWait(driver, timeOutInSeconds)).until(ExpectedConditions.presenceOfElementLocated(by));
        } catch (Exception e) {
            iTakeAScreenshot();

            System.out.println("Test Failure Screenshot generated");
        }
        return null;
    }

    public void getDeviceTime() throws IOException {

        String time = driver.getDeviceTime();
        System.out.println(time);
    }

    public void iTakeAScreenshot() throws IOException {
        DateFormat dateFormat = new SimpleDateFormat("H-m");
        dateFormat.setTimeZone(TimeZone.getTimeZone("GMT"));
        Date date = new Date();
        File scrFile = ((TakesScreenshot) driver).getScreenshotAs(OutputType.FILE);
        FileUtils.copyFile(scrFile, new File("/Users/steveyoung/Desktop/screenshot_" + dateFormat.format(date) + ".png"));
        System.out.println("TEST TEXT:" + scrFile);
    }

    public void setLocation(Integer Latitude, Integer Longitude, Integer Altitude) throws IOException {
        Location location = new Location(Latitude, Longitude, Altitude);
        driver.setLocation(location);
        System.out.println(location);
    }

    public void ouputSessionCapabilities() throws IOException {
        Map<String, Object> testCaps = driver.getSessionDetails();
        System.out.println(testCaps);
    }

    public void swipeDown() throws IOException {
        JavascriptExecutor js = (JavascriptExecutor) driver;
        HashMap<String, String> scrollObject = new HashMap<String, String>();
        scrollObject.put("direction", "down");
        js.executeScript("mobile: swipe", scrollObject);
    }


}
