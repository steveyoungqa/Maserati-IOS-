In the abscence of previous Repos that I cant use for this demonstration
due to privacy issues etc - I have created an example project using an sample project from 
the Appium Git Repo

https://github.com/appium/tutorial/blob/master/projects/ruby_ios/UICatalog6.1.app.zip

https://github.com/appium/ios-uicatalog

I have included these files:

Pom.xml - With everything needed to run Appium with Java and Cucumber
CatalogueTests.feature - With just one Example Tests feature across 3 devices
AppiumIOS.java - Step Definitions for the Gherkin code setting Desired Capabilities and example interaction tests
Driver.java - Typical methods to Find Elements, Take Screenshots etc
Hooks.java - No hooks implement yet

To run this framework you would need to change the app path in the Example Table to where the UICatalog.app is on your machine
i.e change from /Users/steveyoung/Documents/Appium

Other Requirements:

X-Code 9.2
Appium GUI 1.3.2
Carthage, WebDriverAgent
IntelliJ Idea 2017 Ultimate

